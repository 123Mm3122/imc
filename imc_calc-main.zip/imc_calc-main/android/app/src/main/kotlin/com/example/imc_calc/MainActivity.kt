package com.example.imc_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
